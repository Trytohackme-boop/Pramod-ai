"use strict";

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const PORT = Number(process.env.PORT || 3000);
const MAX_BODY = 64 * 1024;
const WINDOW_MS = 60_000;
const RATE_LIMIT = 20;
const requestCounts = new Map();

function json(res, status, payload) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(JSON.stringify(payload));
}

function securityHeaders(res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), geolocation=()");
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > MAX_BODY) {
        reject(new Error("BODY_TOO_LARGE"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); }
      catch { reject(new Error("INVALID_JSON")); }
    });
    req.on("error", reject);
  });
}

function allowedByRateLimit(ip, now = Date.now()) {
  const entry = requestCounts.get(ip);
  if (!entry || now - entry.start >= WINDOW_MS) {
    requestCounts.set(ip, { start: now, count: 1 });
    return true;
  }
  if (entry.count >= RATE_LIMIT) return false;
  entry.count += 1;
  return true;
}

async function handleChat(req, res) {
  const ip = req.socket.remoteAddress || "unknown";
  if (!allowedByRateLimit(ip)) {
    return json(res, 429, { error: "Too many requests. Please wait one minute and try again." });
  }

  let body;
  try { body = await parseBody(req); }
  catch (error) {
    return json(res, error.message === "BODY_TOO_LARGE" ? 413 : 400, {
      error: error.message === "BODY_TOO_LARGE" ? "Request is too large." : "Invalid JSON request."
    });
  }

  if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 20) {
    return json(res, 400, { error: "Send between 1 and 20 chat messages." });
  }

  const messages = body.messages
    .filter(item => item && ["user", "assistant"].includes(item.role) && typeof item.content === "string")
    .map(item => ({ role: item.role, content: item.content.trim().slice(0, 8000) }))
    .filter(item => item.content.length > 0);

  if (!messages.length || messages[messages.length - 1].role !== "user") {
    return json(res, 400, { error: "Your latest message must be a non-empty user message." });
  }

  const apiKey = process.env.AI_API_KEY;
  const apiUrl = process.env.AI_API_URL;
  const model = process.env.AI_MODEL || "gpt-4o-mini";
  if (!apiKey || !apiUrl) {
    return json(res, 503, {
      error: "AI is not configured. Add AI_API_KEY and AI_API_URL to your local .env file."
    });
  }

  try {
    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: [{
          role: "system",
          content: "You are PRAMOD AI, a helpful personal assistant created by Pramod Giri. Reply clearly and accurately. Support Nepali, English, and Japanese. Be honest when you are uncertain."
        }, ...messages],
        temperature: 0.7
      }),
      signal: AbortSignal.timeout(45_000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const providerMessage = data && data.error && data.error.message;
      console.error("AI provider returned status", upstream.status);
      return json(res, 502, { error: providerMessage || "The AI provider could not complete this request." });
    }
    const reply = data && data.choices && data.choices[0] &&
      data.choices[0].message && data.choices[0].message.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return json(res, 502, { error: "The AI provider returned an empty response." });
    }
    return json(res, 200, { reply: reply.trim() });
  } catch (error) {
    console.error("AI request failed:", error.name || "Error");
    return json(res, 502, { error: "Could not reach the AI provider. Check your connection and API settings." });
  }
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon"
};

function serveStatic(urlPath, res) {
  let decoded;
  try { decoded = decodeURIComponent(urlPath); }
  catch { return json(res, 400, { error: "Bad URL." }); }

  const requested = decoded === "/" ? "/index.html" : decoded;
  const filePath = path.resolve(PUBLIC, "." + requested);
  if (!filePath.startsWith(PUBLIC + path.sep) && filePath !== path.join(PUBLIC, "index.html")) {
    return json(res, 403, { error: "Forbidden." });
  }

  fs.readFile(filePath, (error, content) => {
    if (error) return json(res, 404, { error: "Not found." });
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(filePath)] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "no-cache"
    });
    res.end(content);
  });
}

function createServer() {
  return http.createServer((req, res) => {
    securityHeaders(res);
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    if (req.method === "GET" && url.pathname === "/api/health") {
      return json(res, 200, { ok: true, app: "PRAMOD AI", version: "1.0.0" });
    }
    if (req.method === "POST" && url.pathname === "/api/chat") {
      return handleChat(req, res);
    }
    if (req.method === "GET") return serveStatic(url.pathname, res);
    return json(res, 405, { error: "Method not allowed." });
  });
}

if (require.main === module) {
  createServer().listen(PORT, () => {
    console.log(`PRAMOD AI running at http://localhost:${PORT}`);
  });
}

module.exports = { createServer, allowedByRateLimit };
