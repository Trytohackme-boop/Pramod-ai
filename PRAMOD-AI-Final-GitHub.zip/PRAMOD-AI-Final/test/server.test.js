"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { createServer, allowedByRateLimit } = require("../server");

test("rate limiter permits requests within limit and blocks excess", () => {
  const ip = "test-ip-" + Date.now();
  assert.equal(allowedByRateLimit(ip, 1000), true);
  assert.equal(allowedByRateLimit(ip, 1001), true);
});

test("health endpoint returns application status", async () => {
  const server = createServer();
  await new Promise(resolve => server.listen(0, resolve));
  const address = server.address();
  try {
    const response = await fetch(`http://127.0.0.1:${address.port}/api/health`);
    assert.equal(response.status, 200);
    const data = await response.json();
    assert.equal(data.ok, true);
    assert.equal(data.app, "PRAMOD AI");
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});

test("homepage is served", async () => {
  const server = createServer();
  await new Promise(resolve => server.listen(0, resolve));
  const address = server.address();
  try {
    const response = await fetch(`http://127.0.0.1:${address.port}/`);
    assert.equal(response.status, 200);
    assert.match(await response.text(), /PRAMOD AI/);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});

test("chat endpoint validates malformed requests", async () => {
  const server = createServer();
  await new Promise(resolve => server.listen(0, resolve));
  const address = server.address();
  try {
    const response = await fetch(`http://127.0.0.1:${address.port}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: [] })
    });
    assert.equal(response.status, 400);
    const data = await response.json();
    assert.match(data.error, /messages/);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});
