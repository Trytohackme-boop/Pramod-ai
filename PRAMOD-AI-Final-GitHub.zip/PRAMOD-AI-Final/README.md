# PRAMOD AI — Personal AI Assistant

A responsive personal AI chat application built by **Pramod Giri** as a web-development portfolio project.

**Status:** Portfolio starter with a working web server, chat UI, configurable AI-provider integration, local chat history, theme switching, browser voice input, and text-file attachments. A live AI response requires the owner to configure a valid provider API key.

## Screenshots

Add real screenshots of your running app here before presenting this repository to employers. Do not use mockups as proof of working functionality.

```text
docs/
  screenshots/
    desktop.png
    mobile.png
```

## Features

- Responsive desktop and mobile interface
- Chat interface with suggested prompts
- Configurable OpenAI-compatible chat-completions API
- API key kept on the server, never in frontend JavaScript
- Local browser chat history (localStorage)
- Dark and light themes
- Browser speech-to-text where supported
- `.txt`, `.md`, and `.csv` attachment support
- Basic in-memory request rate limiting
- Security response headers
- Node.js built-in test suite

## Tech stack

- HTML5
- CSS3
- Vanilla JavaScript
- Node.js 18+
- Node.js built-in HTTP server and test runner

## Run locally

1. Install Node.js 18 or newer.
2. Download or clone this repository.
3. Open a terminal in the project directory.
4. Install nothing extra; this project uses Node.js built-in modules.
5. Copy `.env.example` to `.env`.
6. Add your AI provider's API key, endpoint, and supported model to `.env`.
7. Start the server:

   ```bash
   npm start
   ```

8. Visit `http://localhost:3000`.

### Environment variables

| Variable | Purpose |
|---|---|
| `AI_API_KEY` | Secret API key from your AI provider |
| `AI_API_URL` | OpenAI-compatible chat-completions endpoint |
| `AI_MODEL` | Model supported by your provider |
| `PORT` | Local port; defaults to 3000 |

The server expects a chat-completions-compatible API that accepts a Bearer token and returns `choices[0].message.content`. Confirm your provider's endpoint, model, pricing, and terms before use.

## Run tests

```bash
npm test
```

The automated tests check the health endpoint, homepage delivery, request validation, and rate-limit helper. They do not test a real external AI provider because that requires the owner's API credentials.

## GitHub upload

1. Create a public repository named `pramod-ai`.
2. Upload all files and folders in this project.
3. Make sure `.env` is NOT uploaded. `.env.example` is safe to share because it contains no secret.
4. Add real screenshots after running the app.
5. Use a clear commit message, for example: `Build PRAMOD AI personal assistant`.
6. Add your live demo URL to this README only after you have deployed and tested it.

## Security and privacy

- Never commit `.env`, API keys, or credentials.
- If an API key is accidentally published, revoke it immediately.
- Do not upload private documents. Text from an attached file is sent to your configured AI provider with your prompt.
- Chat history is stored in this browser's localStorage. It is not encrypted or synchronized to an account.
- Rate limiting is in-memory and resets when the server restarts. Production deployments should use a persistent shared rate limiter, authentication, logging controls, and stricter abuse protection.
- This is a portfolio/demo project, not a production-ready service for sensitive data.

## Current limitations

- Chat persistence is local to the browser; there are no user accounts or cloud database.
- File attachments support text, Markdown, and CSV only; PDF parsing is not included.
- Voice input depends on browser speech-recognition support and permission.
- Text-to-speech output is not included yet.
- AI responses require valid API configuration and may incur provider charges.

## Roadmap

- [ ] Add PDF text extraction
- [ ] Add optional text-to-speech responses
- [ ] Add authentication and database-backed chat history
- [ ] Add deployment workflow and live demo
- [ ] Add screenshots and end-to-end tests

## Author

**Pramod Giri** · Web Developer

This project demonstrates frontend UI development, backend API integration, request validation, basic security practices, and automated testing.
