"use strict";

const form = document.querySelector("#chatForm");
const promptBox = document.querySelector("#prompt");
const messagesEl = document.querySelector("#messages");
const welcome = document.querySelector("#welcome");
const sendButton = document.querySelector("#sendButton");
const fileInput = document.querySelector("#fileInput");
const attachmentInfo = document.querySelector("#attachmentInfo");

let history = [];
let attachmentText = "";

function addMessage(role, content, isPending = false) {
  welcome.hidden = true;
  const article = document.createElement("article");
  article.className = `message ${role}`;
  const label = document.createElement("div");
  label.className = "message-label";
  label.textContent = role === "user" ? "YOU" : "PRAMOD AI";
  const body = document.createElement("div");
  body.className = "message-body";
  body.textContent = content;
  if (isPending) body.classList.add("pending");
  article.append(label, body);
  messagesEl.append(article);
  article.scrollIntoView({ behavior: "smooth", block: "end" });
  return body;
}

function saveHistory() {
  try { localStorage.setItem("pramod-ai-history", JSON.stringify(history.slice(-20))); }
  catch { /* Storage may be disabled; chat still works for this session. */ }
}

function loadHistory() {
  try {
    const stored = JSON.parse(localStorage.getItem("pramod-ai-history") || "[]");
    if (!Array.isArray(stored)) return;
    history = stored.filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string").slice(-20);
    history.forEach(m => addMessage(m.role, m.content));
  } catch { history = []; }
}

async function sendMessage(rawText) {
  const text = rawText.trim();
  if (!text || sendButton.disabled) return;

  const content = attachmentText ? `${text}\n\nAttached file content:\n${attachmentText}` : text;
  attachmentText = "";
  attachmentInfo.textContent = "";
  addMessage("user", text);
  history.push({ role: "user", content });
  saveHistory();

  promptBox.value = "";
  promptBox.style.height = "auto";
  sendButton.disabled = true;
  const pendingBody = addMessage("assistant", "Thinking…", true);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history.slice(-20) })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    pendingBody.classList.remove("pending");
    pendingBody.textContent = data.reply;
    history.push({ role: "assistant", content: data.reply });
    saveHistory();
  } catch (error) {
    pendingBody.classList.remove("pending");
    pendingBody.textContent = `Unable to reply: ${error.message}`;
    history.pop();
    saveHistory();
  } finally {
    sendButton.disabled = false;
    promptBox.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(promptBox.value);
});

promptBox.addEventListener("input", () => {
  promptBox.style.height = "auto";
  promptBox.style.height = `${Math.min(promptBox.scrollHeight, 130)}px`;
});

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

document.querySelector("#newChat").addEventListener("click", () => {
  history = [];
  messagesEl.replaceChildren();
  try { localStorage.removeItem("pramod-ai-history"); } catch {}
  welcome.hidden = false;
  promptBox.focus();
});

document.querySelector("#themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("light");
  try { localStorage.setItem("pramod-ai-theme", document.body.classList.contains("light") ? "light" : "dark"); } catch {}
});

try {
  if (localStorage.getItem("pramod-ai-theme") === "light") document.body.classList.add("light");
} catch {}
loadHistory();

fileInput.addEventListener("change", async () => {
  const file = fileInput.files && fileInput.files[0];
  if (!file) return;
  if (file.size > 300_000) {
    attachmentInfo.textContent = "File too large. Maximum size is 300 KB.";
    fileInput.value = "";
    return;
  }
  if (!/\.(txt|md|csv)$/i.test(file.name)) {
    attachmentInfo.textContent = "Please choose a .txt, .md, or .csv file.";
    fileInput.value = "";
    return;
  }
  attachmentText = await file.text();
  attachmentInfo.textContent = `Attached: ${file.name} — its text will be sent with your next message.`;
  fileInput.value = "";
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const voiceButton = document.querySelector("#voiceButton");
if (SpeechRecognition) {
  voiceButton.addEventListener("click", () => {
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.onresult = event => {
      promptBox.value = `${promptBox.value}${promptBox.value ? " " : ""}${event.results[0][0].transcript}`;
      promptBox.focus();
    };
    recognition.onerror = () => { attachmentInfo.textContent = "Voice input failed. Check your microphone permission."; };
    recognition.start();
  });
} else {
  voiceButton.title = "Voice input is not supported by this browser.";
  voiceButton.addEventListener("click", () => {
    attachmentInfo.textContent = "Voice input is not supported in this browser. Try a supported Chromium browser.";
  });
}
